package library.service;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import library.beans.Book;

public class BookServiceImplTest {

	private BookServiceImpl serviceImpl;
	
	
	@Before
	public void setUp() throws Exception {
		serviceImpl=new BookServiceImpl();
	}

	@Test
	public void testUpdateBook() {
		Book b1=new Book();
		//Book b2=new Book();	
		b1.setPrice("3500");
		b1.setTitle("Spring");
		b1.setPublishYear("2007");
		
		int retVal=serviceImpl.updateBook(b1, 14);
		assertEquals(retVal, 0);
		
	}

	@Test
	public void testRemoveBook() {
		int retVal=serviceImpl.removeBook(14);
		assertEquals(retVal, 0);
		//fail("Not yet implemented");
	}

	

}
