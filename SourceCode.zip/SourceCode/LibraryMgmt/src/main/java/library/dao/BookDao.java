package library.dao;


import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import library.beans.Author;
import library.beans.Book;

@Component
public class BookDao {

	private static  SessionFactory sessionFactory;
	
	public int updateBook(Book b1,int id) {
		int ret=1;
		try {
		AnnotationConfiguration config=new AnnotationConfiguration();
		sessionFactory=config.configure("library/beans/hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Book book=(Book)session.get(Book.class, id);
		Gson gsonBuilder = new GsonBuilder().create();
		String bookString = gsonBuilder.toJson(book);
		System.out.println("book string"+  bookString);
		book.setPrice(b1.getPrice());
		book.setTitle(b1.getTitle());
		book.setPublishYear(b1.getPublishYear());
		session.update(book);
		session.getTransaction().commit();
		session.close();
		}
		catch (Exception e) {
			ret=0;
		}
		return ret;
		
	}

	public int removeBook(int id) {
		int ret=1;
		try {
		AnnotationConfiguration config=new AnnotationConfiguration();
		sessionFactory=config.configure("library/beans/hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Book book=(Book)session.load(Book.class, id);
		book.getAuthorList().clear();
		session.update(book);
//		for(Author a:book.getAuthorList())
//		{
//			book.getAuthorList().remove(a);
//			session.delete(a);
//		}
//		System.out.println(book.getPrice() + "" + book.getId() + " " + book.getPublishYear());
//		Collection<Author> c=book.getAuthorList();
//		book.getAuthorList().remove(0);
//		System.out.println(book.getAuthorList());
//		Gson gsonBuilder = new GsonBuilder().create();
//		String jsonFromJavaArrayList = gsonBuilder.toJson(book);		
//		System.out.println(jsonFromJavaArrayList);
		session.delete(book);
		session.flush();
//		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
//		EntityManager entityManager = entityManagerFactory.createEntityManager();
//		    Book b1 = entityManager.find(Book.class, id);
//		    entityManager.remove(b1);
		session.getTransaction().commit();
		session.close();
		}
		catch (Exception e) {
			ret=0;
		}
		return ret;
	}
	
	public List<Book> getBookDetails()
	{
		AnnotationConfiguration config=new AnnotationConfiguration();
		sessionFactory=config.configure("library/beans/hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Query query=session.createQuery("from BookList2");
		List<Book> bookList =query.list();
		session.getTransaction().commit();
		session.close();
		return bookList;
	}
	public void addBook(Book book, List<Author> authorList) 
	{
		AnnotationConfiguration config=new AnnotationConfiguration();
		sessionFactory=config.configure("library/beans/hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		for (Author author:authorList)
		{
			book.getAuthorList().add(author);
			session.save(author);
			
		}
		session.save(book);
		session.getTransaction().commit();
		session.close();
		
			
	}
}
