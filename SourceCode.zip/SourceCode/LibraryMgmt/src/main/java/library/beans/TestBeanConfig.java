package library.beans;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages="library")
public class TestBeanConfig {

}
