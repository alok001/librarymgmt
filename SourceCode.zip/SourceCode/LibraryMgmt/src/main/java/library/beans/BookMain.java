package library.beans;


import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import library.service.BookServiceImpl;
import library.beans.*;

public class BookMain {

	private static  SessionFactory sessionFactory;
	public static void main(String[] args) {

		
		// inserting xml into database
		AnnotationConfiguration config=new AnnotationConfiguration();
		sessionFactory=config.configure("library/beans/hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();

        SAXReader saxReader = new SAXReader();
        try {
        	//System.out.println(System.getProperty("user.dir"));
        	String path = new File("bookstore.xml").getAbsolutePath();
        	//System.out.println(path);
            Document document = saxReader.read("src///main//java//library//beans//bookstore.xml");

            List<Node> list = document.selectNodes("//book");
            
            
            for(Node node:list)
            {
            	Book bookSax=new Book();
                // List<Author> authorSaList=new ArrayList<Author>();
                
            	//a1.setAuthorId((Math.random())
            	//System.out.println(node.selectSingleNode("title").getText());
            	bookSax.setTitle(node.selectSingleNode("title").getText());
            	bookSax.setPrice(node.selectSingleNode("price").getText());
            	bookSax.setPublishYear(node.selectSingleNode("publishYear").getText());
            	//System.out.println(node.selectSingleNode("publishYear").getText());
            	List<Node> authorNode=node.selectSingleNode("authorList").selectNodes("Author");
            	
            	for(Node auth:authorNode)
            	{
            		 Author a1=new Author();
            		System.out.println(auth.getStringValue());
            		a1.setAuthorName(auth.getStringValue());
            		
            		bookSax.getAuthorList().add(a1);
            		session.saveOrUpdate(a1);
            	}
            	session.save(bookSax);
            }
            session.flush();
            session.beginTransaction().commit();
            session.close();
        } catch (HibernateException e) {
            e.printStackTrace();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
		

	
	
	}

}
