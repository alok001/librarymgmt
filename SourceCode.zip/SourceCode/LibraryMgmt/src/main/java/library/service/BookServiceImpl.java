package library.service;




import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.Test;
import org.springframework.stereotype.Service;


import library.beans.Author;
import library.beans.Book;
import library.dao.BookDao;




@Service
public class BookServiceImpl implements BookService {

	BookDao dao=new BookDao();
	
	public int updateBook(Book book,int id) {
		if(book==null)
		return 0;
		else
		return dao.updateBook(book,id);
	}

	public int removeBook(int id) {
		return dao.removeBook(id);
		
	}

	public List<Book> getBook() {
		return dao.getBookDetails();
	}

	public void addBook(Book book, List<Author> authorList) {
		
		
	}
	
	@Test
	public int loadXMLData(String path) {
		SessionFactory sessionFactory;
		AnnotationConfiguration config=new AnnotationConfiguration();
		sessionFactory=config.configure("library/beans/hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		int xmlLoad=1;
        SAXReader saxReader = new SAXReader();
       // System.out.println(System.getProperty("jboss.server.config.dir")+"\\bookstore.xml");
        String absPath=System.getProperty("jboss.server.config.dir")+"\\"+path;
        try {
      
            Document document = saxReader.read(absPath);
            List<Node> list = document.selectNodes("//book");
        	
          
    		
            for(Node node:list)
            {
            	Book bookSax=new Book();
            	bookSax.setTitle(node.selectSingleNode("title").getText());
            	bookSax.setPrice(node.selectSingleNode("price").getText());
            	bookSax.setPublishYear(node.selectSingleNode("publishYear").getText());
            	//System.out.println(node.selectSingleNode("publishYear").getText());
            	List<Node> authorNode=node.selectSingleNode("authorList").selectNodes("Author");
            	
            	for(Node auth:authorNode)
            	{
            		Author a1=new Author();
            		System.out.println(auth.getStringValue());
            		a1.setAuthorName(auth.getStringValue());
            		bookSax.getAuthorList().add(a1);
            		session.saveOrUpdate(a1);
            	}
            	session.save(bookSax);
            }
            session.flush();
            session.beginTransaction().commit();
            session.close();
        } catch (HibernateException e) {
        	xmlLoad=0;
            e.printStackTrace();
        } catch (DocumentException e) {
        	xmlLoad=0;
            e.printStackTrace();
        }
		
		return xmlLoad;
	}

}
