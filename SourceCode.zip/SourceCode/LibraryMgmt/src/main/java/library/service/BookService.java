package library.service;

import java.util.List;



import library.beans.Author;
import library.beans.Book;


public interface BookService {

	int updateBook(Book book,int id);
	int removeBook(int id);
	List<Book> getBook();
	void addBook(Book book,List<Author> authorList);
	int loadXMLData(String path);
}
