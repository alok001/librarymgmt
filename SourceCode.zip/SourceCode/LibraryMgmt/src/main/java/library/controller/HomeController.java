package library.controller;

//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertTrue;

//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
//import org.junit.Test;
import org.springframework.stereotype.Controller;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.TestContext;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import library.beans.Book;
import library.beans.TestBeanConfig;
import library.service.BookServiceImpl;


@Controller
public class HomeController {

	Gson gsonBuilder = new GsonBuilder().create();
	
	@Autowired
	BookServiceImpl service;// =new BookServiceImpl();
	
	/*
	 This operation gets the default home page
	  */
	 
	@RequestMapping("/home")
	public String getHome() {
		return "Home";
	}
	/*
	 This operation renders the view for book details
	  */
	@RequestMapping("/getBook")
	public String getBook() {
		
		return "BookList";
	}
	/*
	 This is an internal ajax call which retreive all book information .It sends response back in json string
	  */
	
	@RequestMapping("/loadData")     
	@ResponseBody
	public String check(HttpServletRequest request, HttpServletResponse response) 
	{
		System.out.println("inside ajax call");
		 service =getObject();
		List<Book> bookList=service.getBook();
		
	

		String jsonFromJavaArrayList = gsonBuilder.toJson(bookList);		
		System.out.println(jsonFromJavaArrayList);
		
	   return jsonFromJavaArrayList;
	}
	/*
	 This is an internal ajax call which updates book information 
	  */
	
	
	@RequestMapping(value="/updateBook",method=RequestMethod.POST)     
	@ResponseBody
	public String updateBook(HttpServletRequest request, HttpServletResponse response,@RequestBody Book b1) 
	{
		System.out.println("inside update method ");
		System.out.println(" book " + b1.getId() + " " + b1.getPublishYear() + " " + b1.getPrice());
		service=getObject();
		int val=service.updateBook(b1, b1.getId());
		//assertEquals(val, 1);
		//assertEquals(val,0);
		if(val==1)
		return gsonBuilder.toJson("true");
		else
			return gsonBuilder.toJson("false");
	}
	/*
	 This is an internal ajax call which removes the book information
	  */
	
	@RequestMapping(value="/deleteBook",method=RequestMethod.POST)     
	@ResponseBody
	public String deleteBook(HttpServletRequest request, HttpServletResponse response,@RequestParam String id) 
	{
		System.out.println(" id " + id);
		int val=0;
		try {
		int bookID=Integer.parseInt(id);
		service=getObject();
		 val=service.removeBook(bookID);
		}
		catch(NumberFormatException nfe)
		{
			val=0;
		}
		//assertEquals(val, 1);
		//assertEquals(val,0);
		if(val==1)
			
		return gsonBuilder.toJson("true");
		else
			return gsonBuilder.toJson("false");
	}
	
	
	@RequestMapping(value="/loadBook",method=RequestMethod.GET)     
	@ResponseBody
	public String loadData(HttpServletRequest request, HttpServletResponse response) 
	{
		//System.out.println(" id " + id);
		int val=0;
		try {
		//int bookID=Integer.parseInt(id);
		service=getObject();
		 val=service.loadXMLData("bookstore.xml");
		}
		catch(NumberFormatException nfe)
		{
			val=0;
		}
		
		if(val==1)
		return gsonBuilder.toJson("true");
		else
			return gsonBuilder.toJson("false");
	}
	BookServiceImpl getObject() {
		if(service==null)
				{
					return new BookServiceImpl();
				}
		else
			return service;
	}
}
